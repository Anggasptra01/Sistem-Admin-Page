const express = require('express');
const router = express.Router();
const db = require('../db');

router.get('/', (req, res) => {
  db.query('SELECT * FROM produk', (err, produk) => {
    if (err) throw err;
    db.query('SELECT pembelian.id, produk.nama, pembelian.jumlah, pembelian.total, pembelian.status, pembelian.created_at FROM pembelian JOIN produk ON pembelian.produk_id = produk.id', (err, pembelian) => {
      if (err) throw err;
      res.render('index', { produk, pembelian });
    });
  });
});

router.post('/beli', (req, res) => {
  const { produk_id, jumlah } = req.body;
  db.query('SELECT harga FROM produk WHERE id = ?', [produk_id], (err, result) => {
    if (err) throw err;
    const harga = result[0].harga;
    const total = harga * jumlah;

    db.query('INSERT INTO pembelian (produk_id, jumlah, total) VALUES (?, ?, ?)', [produk_id, jumlah, total], (err) => {
      if (err) throw err;

      db.query('SELECT * FROM stock_produk WHERE produk_id = ?', [produk_id], (err, stock) => {
        if (stock.length > 0) {
          db.query('UPDATE stock_produk SET jumlah = jumlah + ? WHERE produk_id = ?', [jumlah, produk_id]);
        } else {
          db.query('INSERT INTO stock_produk (produk_id, jumlah) VALUES (?, ?)', [produk_id, jumlah]);
        }
        res.redirect('/');
      });
    });
  });
});

router.post('/cancel/:id', (req, res) => {
  const id = req.params.id;
  db.query('SELECT * FROM pembelian WHERE id = ?', [id], (err, result) => {
    if (err) throw err;
    const pembelian = result[0];
    if (pembelian.status === 'DIBATALKAN') return res.redirect('/');

    db.query('UPDATE pembelian SET status = "DIBATALKAN" WHERE id = ?', [id], (err) => {
      if (err) throw err;
      db.query('UPDATE stock_produk SET jumlah = jumlah - ? WHERE produk_id = ?', [pembelian.jumlah, pembelian.produk_id], (err) => {
        if (err) throw err;
        res.redirect('/');
      });
    });
  });
});

module.exports = router;
